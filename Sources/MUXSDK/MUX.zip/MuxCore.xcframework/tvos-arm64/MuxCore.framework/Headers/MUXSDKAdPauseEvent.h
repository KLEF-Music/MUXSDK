#ifndef MUXSDKAdPauseEvent_h
#define MUXSDKAdPauseEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdPauseEventType;

@interface MUXSDKAdPauseEvent : MUXSDKPlaybackEvent
@end

#endif
