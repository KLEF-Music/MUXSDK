#ifndef MUXSDKAdFirstQuartileEvent_h
#define MUXSDKAdFirstQuartileEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdFirstQuartileEventType;

@interface MUXSDKAdFirstQuartileEvent : MUXSDKPlaybackEvent
@end

#endif
