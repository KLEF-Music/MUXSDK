#ifndef MUXSDKAdErrorEvent_h
#define MUXSDKAdErrorEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdErrorEventType;

@interface MUXSDKAdErrorEvent : MUXSDKPlaybackEvent
@end

#endif
