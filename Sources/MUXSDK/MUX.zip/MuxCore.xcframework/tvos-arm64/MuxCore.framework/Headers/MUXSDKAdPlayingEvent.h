#ifndef MUXSDKAdPlayingEvent_h
#define MUXSDKAdPlayingEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdPlayingEventType;

@interface MUXSDKAdPlayingEvent : MUXSDKPlaybackEvent
@end

#endif
