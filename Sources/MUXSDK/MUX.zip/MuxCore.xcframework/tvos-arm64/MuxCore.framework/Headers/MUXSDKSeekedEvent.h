#ifndef MUXSDKSeekedEvent_h
#define MUXSDKSeekedEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventSeekedEventType;

@interface MUXSDKSeekedEvent : MUXSDKPlaybackEvent
@end

#endif
