#ifndef MUXSDKPlayEvent_h
#define MUXSDKPlayEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventPlayEventType;

@interface MUXSDKPlayEvent : MUXSDKPlaybackEvent
@end

#endif
