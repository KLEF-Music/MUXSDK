#ifndef MUXSDKAdMidpointEvent_h
#define MUXSDKAdMidpointEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdMidpointEventType;

@interface MUXSDKAdMidpointEvent : MUXSDKPlaybackEvent
@end

#endif
