#ifndef MUXSDKAdThirdQuartileEvent_h
#define MUXSDKAdThirdQuartileEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdThirdQuartileEventType;

@interface MUXSDKAdThirdQuartileEvent : MUXSDKPlaybackEvent
@end

#endif
