#ifndef MUXSDKPlayingEvent_h
#define MUXSDKPlayingEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventPlayingEventType;

@interface MUXSDKPlayingEvent : MUXSDKPlaybackEvent
@end

#endif
