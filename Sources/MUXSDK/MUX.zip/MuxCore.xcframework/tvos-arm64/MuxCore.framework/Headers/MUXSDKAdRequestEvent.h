#ifndef MUXSDKAdRequestEvent_h
#define MUXSDKAdRequestEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdRequestEventType;

@interface MUXSDKAdRequestEvent : MUXSDKPlaybackEvent
@end

#endif
