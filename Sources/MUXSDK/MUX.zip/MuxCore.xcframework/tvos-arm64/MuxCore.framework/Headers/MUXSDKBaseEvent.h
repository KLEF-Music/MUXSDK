#ifndef MUXSDKBaseEvent_h
#define MUXSDKBaseEvent_h

#import "MUXSDKEventTyping.h"
#import <Foundation/Foundation.h>

@interface MUXSDKBaseEvent : NSObject <MUXSDKEventTyping>

@end

#endif
