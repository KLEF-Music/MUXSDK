#ifndef MUXSDKAdEndedEvent_h
#define MUXSDKAdEndedEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdEndedEventType;

@interface MUXSDKAdEndedEvent : MUXSDKPlaybackEvent
@end

#endif
