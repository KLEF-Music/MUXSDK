#ifndef MUXSDKViewInitEvent_h
#define MUXSDKViewInitEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventViewInitEventType;

@interface MUXSDKViewInitEvent : MUXSDKPlaybackEvent
@end

#endif
