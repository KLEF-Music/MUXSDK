#ifndef MUXSDKViewEndEvent_h
#define MUXSDKViewEndEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventViewEndEventType;

@interface MUXSDKViewEndEvent : MUXSDKPlaybackEvent
@end

#endif
