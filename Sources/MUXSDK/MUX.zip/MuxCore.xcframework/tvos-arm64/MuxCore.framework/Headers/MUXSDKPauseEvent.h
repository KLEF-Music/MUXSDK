#ifndef MUXSDKPauseEvent_h
#define MUXSDKPauseEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventPauseEventType;

@interface MUXSDKPauseEvent : MUXSDKPlaybackEvent
@end

#endif
