#ifndef MUXSDKAdResponseEvent_h
#define MUXSDKAdResponseEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdResponseEventType;

@interface MUXSDKAdResponseEvent : MUXSDKPlaybackEvent
@end

#endif
