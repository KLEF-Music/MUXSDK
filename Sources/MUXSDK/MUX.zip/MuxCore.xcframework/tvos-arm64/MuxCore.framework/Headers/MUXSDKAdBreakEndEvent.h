#ifndef MUXSDKAdBreakEndEvent_h
#define MUXSDKAdBreakEndEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdBreakEndEventType;

@interface MUXSDKAdBreakEndEvent : MUXSDKPlaybackEvent
@end

#endif
