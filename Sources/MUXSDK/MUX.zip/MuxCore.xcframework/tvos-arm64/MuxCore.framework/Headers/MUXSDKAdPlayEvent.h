#ifndef MUXSDKAdPlayEvent_h
#define MUXSDKAdPlayEvent_h

#import "MUXSDKPlaybackEvent.h"
#import <Foundation/Foundation.h>

extern NSString * _Nonnull const MUXSDKPlaybackEventAdPlayEventType;

@interface MUXSDKAdPlayEvent : MUXSDKPlaybackEvent
@end

#endif
